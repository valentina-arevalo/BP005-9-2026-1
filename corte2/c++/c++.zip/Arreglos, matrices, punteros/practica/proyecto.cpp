#include <iostream>
using namespace std;
#include <stdlib.h> 

void leerArreglo(int *datos, int n) {
    int i;
    for (i = 0; i < n; i++) {
        cout << "Arreglo [%d]: ", i;
        cin >> "%d", &datos[i];
    }
}

void mostrarArreglo(int *datos, int n) {
    int i;
    cout << "Arreglo guardado: ";
    for (i = 0; i < n; i++) {
        cout << "%d ", datos[i];
    }
    cout << "\n";
}

void analizarArreglo(int *datos, int n, int *suma, int *mayor, int *menor) {
    int i;
    *suma = 0;
    *mayor = datos[0];
    *menor = datos[0];

    for (i = 0; i < n; i++) {
        *suma += datos[i];
        if (datos[i] > *mayor) {
            *mayor = datos[i];
        }
        if (datos[i] < *menor) {
            *menor = datos[i];
        }
    }
}

void leerMatriz(int *matriz, int filas, int columnas) {
    int i, j;
    for (i = 0; i < filas; i++) {
        for (j = 0; j < columnas; j++) {
            cout << "Matriz [%d][%d]: ", i, j;
            cin >> "%d", &matriz[i * columnas + j];
        }
    }
}

void mostrarMatriz(int *matriz, int filas, int columnas) {
    int i, j;
    cout << "Matriz guardada:\n";
    for (i = 0; i < filas; i++) {
        for (j = 0; j < columnas; j++) {
            cout << "%d\t", matriz[i * columnas + j];
        }
        cout << "\n";
    }
}

int sumarMatriz(int *matriz, int filas, int columnas) {
    int i, j;
    int suma = 0;
    for (i = 0; i < filas; i++) {
        for (j = 0; j < columnas; j++) {
            suma += matriz[i * columnas + j];
        }
    }
    return suma;
}

int main() {
    int n_arreglo;
    int *arregloDinamico = NULL;
    int sumaArr, mayorArr, menorArr;
    int f_matriz, c_matriz;
    int *matrizDinamica = NULL;
    int sumaMat;
    cout << "        PROYECTO INTEGRADOR: MEMORIA DINAMICA     \n";
  
    cout << "--- Bloque 1: Arreglo Dinamico ---\n";
    cout << "¿Cuantos elementos desea asignar al arreglo?: ";
    cin >> "%d", &n_arreglo;

    arregloDinamico = (int *)malloc(n_arreglo * sizeof(int);
    if (arregloDinamico == NULL) {
        cout << "Error: No se pudo asignar memoria para el arreglo.\n";
        return 1; 
    }

    leerArreglo(arregloDinamico, n_arreglo;
    cout << "\n";
    mostrarArreglo(arregloDinamico, n_arreglo;
    analizarArreglo(arregloDinamico, n_arreglo, &sumaArr, &mayorArr, &menorArr;

    cout << "\nReporte del Arreglo:\n";
    cout << "-> Suma de elementos: %d\n", sumaArr;
    cout << "-> Elemento mayor: %d\n", mayorArr;
    cout << "-> Elemento menor: %d\n\n", menorArr;

    cout << "--- Bloque 2: Matriz Dinamica Lineal ---\n";
    cout << "Ingrese numero de filas: ";
    cin >> "%d", &f_matriz;
    cout << "Ingrese numero de columnas: ";
    cin >> "%d", &c_matriz;

    matrizDinamica = (int *)malloc(f_matriz * c_matriz * sizeof(int);
    if (matrizDinamica == NULL) {
        cout << "Error: No se pudo asignar memoria para la matriz.\n";
        free(arregloDinamico; 
        return 1;
    }

    leerMatriz(matrizDinamica, f_matriz, c_matriz;
    cout << "\n";
    mostrarMatriz(matrizDinamica, f_matriz, c_matriz;
    sumaMat = sumarMatriz(matrizDinamica, f_matriz, c_matriz;

    cout << "\nReporte de la Matriz:\n";
    cout << "-> Suma total de celdas: %d\n\n", sumaMat;

    cout << "Liberando memoria asignada dinamicamente...\n";
    
    free(arregloDinamico;
    arregloDinamico = NULL;
    
    free(matrizDinamica;
    matrizDinamica = NULL;

    cout << "Programa finalizado con exito.\n";
    return 0;
}
