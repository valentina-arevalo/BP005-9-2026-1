#include <iostream>
using namespace std;

int potencia(int base,int exponente;

int main(){

int b,e;

cout << "Base: ";
cin >> "%d",&b;

cout << "Exponente: ";
cin >> "%d",&e;

cout << "Resultado: %d", potencia(b,e);

return 0;
}

int potencia(int base,int exponente){

int i;
int resultado=1;

for(i=1;i<=exponente;i++){
resultado*=base;
}

return resultado;

}
