#include <iostream>
using namespace std;

int main() {
    int i, j;

    for(i = 1; i <= 6; i++) {
        for(j = 1; j <= 6; j++) {
            cout << "@ ";
        }
        cout << "\n";
    }

    return 0;
}
