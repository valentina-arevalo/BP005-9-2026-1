#include <iostream>
using namespace std;

 int main() {
 int i; // Variable de control

 for (i = 1; i <= 5; i++) { // Inicio, condicion y actualizacion
cout << " %d\n", i; // Muestra el valor actual
}
 return 0;
}
