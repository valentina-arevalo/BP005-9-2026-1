#include <iostream>
using namespace std;

 int main() {
 int numero = 7; // Numero del que se desea la tabla
 int i; // Contador

 for (i = 1; i <= 10; i++) {
 cout << " %d x %d = %d\n", numero, i, numero * i;
 }

 return 0;
 }
