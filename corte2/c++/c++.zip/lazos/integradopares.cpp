#include <iostream>
using namespace std;

 int main() {
 int i;
 int contador = 0; 

 for (i = 1; i <= 20; i++) {
 if (i % 2 == 0) {
   cout << " %d es par\n", i;
    contador++;
   }
 }

   cout << "Cantidad de numeros pares: %d\n", contador;

 return 0;
 }
