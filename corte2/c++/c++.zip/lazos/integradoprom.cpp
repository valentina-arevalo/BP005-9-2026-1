#include <iostream>
using namespace std;

 int main() {
 int i; 
 float nota; 
 float suma = 0.0; 
 float promedio; 

for (i = 1; i <= 4; i++) {
 cout << "Ingrese la nota %d: ", i;
 cin >> " %f", &nota;

 suma = suma + nota; 
 }

 promedio = suma / 4.0;

 cout << "El promedio es: %.2f\n", promedio;

 return 0;
 }
